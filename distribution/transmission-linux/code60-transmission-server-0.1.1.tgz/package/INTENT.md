# Transmission intent

Transmission gives a calling orchestrator a deterministic outer loop for long-running work. Each task starts in a fresh harness session to reduce context rot. A separate verifier evaluates the worker’s result. The orchestrator can rely on a small set of outcomes even when an individual task takes several attempts.

## Priorities, in order

1. Extremely low-friction setup for the user.
2. Extremely low-friction setup for the user. The repetition is intentional.
3. Autonomy over long runs. Failed tests, verifier feedback, and retries are ordinary parts of the work.
4. Reasonable recovery from interruptions a developer encounters on one machine.
5. Reasonably secure defaults within Transmission’s own sphere of responsibility.

## From request to running workflow

The user describes what they want to accomplish. The calling orchestrator, acting through the harness, uses the MCP tool’s guidance to design a workflow. The caller defines the tasks, their order, and their completion criteria. The harness presents the workflow and asks the user to confirm it. Ordinary coding tasks should require no project-specific Transmission setup or knowledge of its orchestration API from the user.

That confirmation authorizes autonomous execution of the agreed scope. Transmission owns session lifecycle and workflow decisions. Automatic approval of decisions during execution is configurable and enabled by default. Return to the user only when their intent needs clarification, the scope needs to change, or the workflow genuinely cannot proceed.

## Implementation and verification

Workers use the harness’s normal tools, command execution, and permissions. Transmission starts a fresh worker session for each task and keeps verification separate from implementation. The workflow can express the verifier’s criteria as a prompt.

When verification calls for repairs, the original worker receives the feedback and can try again up to a configured limit. At that limit, restart the task in a fresh session, subject to the configured retry limit. A failed test or a request for repair can be handled inside this loop without involving the user.

## Recovery on one machine

| Interruption | Expected behavior |
| --- | --- |
| The MCP client closes | The approved workflow keeps running. |
| The machine reboots | Resume from the last completed task and continue with the first unfinished task. |
| The harness dies mid-task | Retry that task in a fresh session within the configured retry limit. |

## What the caller can rely on

| Workflow status | Information returned |
| --- | --- |
| Running | Which task is running. |
| Completed | The result and the verifier’s verdict. |
| Needs input | The specific decision the user needs to make. |
| Failed | Why the workflow failed and what it tried. |
| Cancelled | Confirmation that the workflow was cancelled. |

## Architectural limits

The harness owns development permissions and their enforcement. Transmission has no additional protection mandate. A new security layer on top of the harness is outside the project’s scope.

The recovery target is an individual developer’s machine and the interruptions described above. Rebuilding Temporal is outside the project’s scope. When architectural choices compete, the priorities above govern the trade-off.
