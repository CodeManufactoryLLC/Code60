# Transmission

Transmission runs an approved coding workflow in an existing Git project. The calling assistant designs the tasks and asks you to confirm them. Each task gets a fresh worker. A separate verifier inspects the project, runs checks, and returns a verdict. Rejected work goes back to the same worker with the verifier’s feedback.

## Connect your assistant

On macOS or Linux x64 with glibc, with Node 24.22 or later in the 24.x series, add this stdio MCP server to your assistant. Sign in to Codex once using your usual Codex login.

```json
{
  "mcpServers": {
    "transmission": {
      "command": "npx",
      "args": ["-y", "code60-transmission-server", "mcp"]
    }
  }
}
```

For an unpublished candidate, install the tarball and run `code60 mcp-config` for the exact local server entry. A first connection starts the local engine. Describe the outcome you want, review the caller’s proposed tasks and verification criteria, and confirm the workflow.

## Execution

The MCP caller sends the approved workflow to `start_workflow`. Project paths are absolute. The caller can load the same input from a saved JSON definition.

```json
{
  "repository": "/absolute/path/to/project",
  "confirmed": true,
  "idempotencyKey": "my-project-duration-parser-1",
  "tasks": [{
    "name": "Repair duration parsing",
    "instructions": "Reproduce the fractional-duration bug, fix the parser, and add regression coverage.",
    "verify": "Exercise positive and negative fractional durations against the public API. Explain the observed behavior.",
    "checks": ["npm test"]
  }]
}
```

The engine uses a single ACP client implementation and the maintained `@agentclientprotocol/codex-acp` package, which includes a compatible Codex executable. Codex owns development tools, configuration, authentication, filesystem access and command execution. The project folder is the session working directory. The ACP adapter supports normal Codex configuration and the optional `CODEX_PATH` override. Transmission advertises no client terminal or filesystem services.

Each worker submission is tied to a Git tree snapshot. Workers receive the task instructions and requested commands. Verifiers receive the independent verification prompt and the candidate summary in a separate session. Put shared requirements in the task instructions. Optional explicit checks run in the verifier’s harness and their reported results are included in the verdict. Acceptance requires a valid affirmative verdict on the same source tree. A verifier can tell the original worker exactly what to repair. By default a worker gets two repairs before replacement and a task gets two fresh-session retries. The workflow can override `repairs` and `retries`.

The initial worktree, including existing staged, unstaged and nonignored untracked source, is the diff baseline. Transmission uses a disposable index and private Git objects. Ordinary results remain uncommitted. Use one active workflow per checkout and avoid simultaneous external source edits if you need attribution of the final patch.

## Decisions, results and recovery

| Status | What the caller receives |
| --- | --- |
| running | Current task and role |
| pausing | Current task while active agents are stopping |
| paused | Preserved progress, waiting for an explicit resume |
| needs_input | A decision with a question ID and, for a permission request, the choices offered by the harness |
| completed | The result, verifier verdict, and ordered accepted task records |
| failed | The reason and attempt history |
| cancelled | Confirmation and the accepted tasks so far |

The MCP tools include status, paginated events, the paginated accepted diff, answering questions, steering, pause, resume and cancellation. `autoApprove` defaults to true and selects a one-time allowance when the harness offers one. Set it to false to receive those decisions yourself. Requirements and scope questions always go to the caller. The harness enforces its effective permissions.

Call `pause_workflow` with `{"runId":"<workflow ID>"}` to interrupt the active worker or verifier immediately. The workflow enters `pausing` before agent shutdown and returns `paused` once its agents and execution loop have stopped. Working files, HEAD, staging, accepted tasks, guidance and spent allowances are preserved. A paused workflow still reserves its checkout. Repeating pause returns the current pause outcome; cancellation can supersede an in-flight pause.

Call `resume_workflow` with the same run ID to continue. The first unfinished task starts with fresh worker and verifier sessions, including when verification was interrupted. Pause does not spend a fresh-session retry or replenish repair/retry allowances. The new worker is instructed to inspect partial work before repeating consequential actions. Unanswered scope questions survive pause and still require an answer; an answer given while paused is saved without starting work. Permission questions for stopped sessions are withdrawn and must be requested again by the fresh harness. Resume during `pausing` is rejected. Repeated resume after continuation returns the current snapshot; ended workflows reject pause and resume.

The engine stays up when the MCP client disconnects. Approved tasks, questions, verdicts, and attempts are stored in SQLite. On restart, the engine continues with the first unfinished task and retains partial working-tree changes. Explicitly paused workflows stay paused until `resume_workflow`; a restart during `pausing` also leaves the workflow paused. Restarting the engine preserves the task’s retry allowance. A lost harness consumes a fresh-session retry. Completed tasks stay accepted. Cancellation leaves the files available for review.

## Revise unfinished work

To change tasks or verification criteria within the same run, call `pause_workflow` and wait for `paused`. Read `get_workflow_plan` with `{"runId":"<workflow ID>"}`. It returns `planRevision`, `activeTaskIndex`, and the full task definitions, including instructions, independent verification prompts, and optional check commands. Tasks before the active index are completed and cannot be revised.

Present the revised unfinished tasks and criteria to the user and obtain confirmation. Submit the complete replacement for the unfinished portion, including the interrupted current task, to `revise_workflow`:

```json
{
  "runId": "6ef301cf-b89e-4c11-af33-e11b1171a6b8",
  "expectedRevision": 0,
  "idempotencyKey": "duration-parser-revision-1",
  "confirmed": true,
  "remainingTasks": [{
    "name": "Cover scientific notation",
    "instructions": "Extend the existing parser to support scientific notation and add regression tests. Preserve the completed parsing changes.",
    "verify": "Independently test positive, negative, fractional and malformed scientific notation. Check backward compatibility with existing duration inputs.",
    "checks": ["npm test"]
  }]
}
```

Use the revision returned by `get_workflow_plan` as `expectedRevision`. The replacement can add, remove, reorder, or rewrite unfinished tasks. Include at least one task; the completed prefix plus the replacement may contain at most 100 tasks. Each task must include its full instructions and verification prompt. Omitting `checks` removes that task's previous explicit check requirements. Repository settings, permission settings, and repair/retry limits remain fixed.

The response is a workflow snapshot with an incremented `planRevision`. The run remains paused until a separate `resume_workflow` call. Resume starts fresh sessions for the first revised unfinished task and verifies against its new criteria. The current task position retains its spent repair and retry allowances, even if its task is replaced; later tasks receive their ordinary allowances when reached.

Completed task definitions, results, verdicts, accepted diffs, the original baseline, working files, HEAD, staging, and prior events remain intact. When the current task changes, its old feedback, guidance, messages, and question are archived and cleared from active execution. Add any still-relevant guidance after revision. When only later tasks change, current task context and unanswered questions are retained.

Each revision is recorded as a `plan_revised` event with the previous unfinished task list, the normalized revision request, and any archived context. New execution events carry `detail.planRevision`; older events without it belong to revision zero. The revised plan and history survive restart and stay paused until explicit resume.

Retry an uncertain revision with the exact same request and key. An accepted retry returns the current snapshot, even after later revisions, resume, restart, or completion. A changed request under the same key is rejected. A new revision with a stale `expectedRevision` is rejected without applying changes; read the current plan and reassess it before making a new request. Replaying the original `start_workflow` request still identifies this run and returns its current snapshot.

New revisions require a fully paused run. Running, pausing, input-waiting without explicit pause, stopping, and ended workflows reject them. Use cancellation when there is no remaining work to run.

## Observe task progress

A client can render the ordered tasks by calling `get_workflow` with only the run ID. For example, during verification the response can look like this:

```json
{
  "runId": "6ef301cf-b89e-4c11-af33-e11b1171a6b8",
  "planRevision": 0,
  "status": "running",
  "task": "Implement the fix",
  "phase": "verifier",
  "tasks": [
    { "index": 0, "name": "Implement the fix", "state": "verifying" },
    { "index": 1, "name": "Document it", "state": "pending" }
  ],
  "activeTaskIndex": 0,
  "eventCursor": 37,
  "accepted": [],
  "attempts": []
}
```

Each task keeps its zero-based index even when names repeat. The active row can be `implementing`, `verifying`, `repairing`, `needs_input`, `pausing`, or `paused`. Pausing and paused runs retain their active index. A terminal run has a null active index. Previously accepted rows stay `accepted`, the interrupted row records `failed` or `cancelled`, and unstarted rows stay `pending`.

For subsequent activity, call `get_workflow_events` with the same run ID and `after` set to the snapshot’s `eventCursor`. Use the last returned sequence for the next page. Sequence numbers can have gaps between events for a run. Use `after: 0` for earlier history, or refresh `get_workflow` for another complete snapshot.

Private state defaults to `~/Library/Application Support/Code60 Transmission/workflows`. On Linux, state defaults to `$XDG_STATE_HOME/code60-transmission/workflows` or `~/.local/state/code60-transmission/workflows`. Ordinary connections enable `code60-transmission.service` when a systemd user manager is available. Without one, reconnect after login to recover work. Explicit state directories skip service registration. Linux requires Git and the npm platform dependency for Codex, or an explicit `CODEX_PATH`.

On macOS, the first ordinary connection registers a per-user LaunchAgent to restart the engine at login. Keep Node and the installed package available at their original paths for login restart. Credentials supplied only through transient shell environment variables need to be available again after login. For an isolated engine, set `TRANSMISSION_STATE_DIR` to a new absolute directory. Isolated engines skip login registration. Use `code60 status` and `code60 stop` with the same state directory.

## Development and validation

Run `npm ci`, `npm run typecheck`, and `npm test`. The HTTP contract is generated from the same schemas used by MCP and the engine. Run `npm run contracts:check` after changing the interface.

For the installed-package live test, run `npm pack` followed by `npm run acceptance:installed -- /absolute/path/to/candidate.tgz /absolute/path/to/new-evidence-directory`. This uses the normal Codex login and real model calls. It installs the package, clones a pinned upstream repository, and exercises rejection, same-session repair, fresh verification, and a second task over MCP. Pass `--agent-caller` to have a real Codex caller design the workflow and submit it over MCP after the test supplies confirmation. The default caller uses the MCP SDK. An independent grader runs the upstream suite and additional public-API assertions and checks the dirty baseline, index and HEAD. The script saves the report, diff, events and uncommitted checkout, then stops the isolated engine.

See [project intent](INTENT.md) and the [HTTP contract](reference/openapi.json).
